# -*- coding: iso-8859-1 -*-
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
#from qgis.PyQt.QtWidgets import *
from qgis.gui import QgsMessageBar
from qgis.core import *
from PyQt5 import QtCore
#from qgis.PyQt.QtCore import QtCore	
from qgis.PyQt.QtWidgets import QDialog, QDialogButtonBox,QAction, QMenu
##QMainWindow, QApplication

# Import libs 
import timeit, math, sys, os.path;
sys.path.append(os.path.dirname(os.path.abspath(__file__))) 
sys.path.append(os.path.dirname(__file__))

# chargement des fichiers d'interface graphique
from CEN_14757 import doDlgBox1
from CEN_14757 import doAbout
from CEN_14757 import fonctionsCEN_14757


class MainPluginCEN(object):
  def __init__(self,iface):
    self.name = "CEN 14757"
    #r�f�rence � l'objet interface QGIS
    self.iface = iface
    # reference to the canvas
    self.canvas = self.iface.mapCanvas()

  def initGui(self):
    self.menu=QMenu(" CEN 14757 ")

    #d�claration des actions �l�mentaires
    menuIcon = getThemeIcon("CEN_14757.png")
    self.commande1 = QAction(QIcon(menuIcon),"CEN 14757",self.iface.mainWindow())
    self.commande1.setText("CEN 14757")

    menuIcon = getThemeIcon("about.png")
    self.about = QAction(QIcon(menuIcon), "A propos ...", self.iface.mainWindow())
    self.about.setText("A propos ...")

    #Construction du menu
    self.menu.addAction(self.commande1)
    self.menu.addSeparator()
    self.menu.addAction(self.about)

    """
    #Construction de la barre d'outils
    self.toolBarName = "Ma Barre"
    toolbar = self.iface.addToolBar(self.toolBarName)
    self.toolbar = toolbar
    self.toolbar.addAction(self.commande1)
    """
    #Connection de la commande � l'action PYQT5
    self.commande1.triggered.connect(self.LoadDlgBox1)
    self.about.triggered.connect(self.doInfo)
   
    menuBar = self.iface.mainWindow().menuBar()
    menuBar.addMenu(self.menu)
    
    # Add toolbar button and menu item
    self.iface.addToolBarIcon(self.commande1)
    self.iface.addPluginToMenu("CEN 14757", self.commande1)
    
                     
  def unload(self): 
     #M�thode au d�chargement de l'extension
     self.iface.removePluginMenu("CEN 14757",self.commande1)
     self.iface.removeToolBarIcon(self.commande1)


  #Exemple d'appel d'une bo�te de dialogue (ici : exemple d'objets Qt)
  def LoadDlgBox1(self):
      d = doDlgBox1.Dialog()
      #d.show()
      d.exec_()
 
  def doInfo(self):
      d = doAbout.Dialog()
      d.exec_()
     
#Fonction de reconstruction du chemin absolu vers la ressource image
def getThemeIcon(theName):
    myPath = CorrigePath(os.path.dirname(__file__));
    myDefPathIcons = myPath + "/data/"
    myDefPath = myPath.replace("\\","/")+ theName;
    myDefPathIcons = myDefPathIcons.replace("\\","/")+ theName;
    myCurThemePath = QgsApplication.activeThemePath() + "/plugins/" + theName;
    myDefThemePath = QgsApplication.defaultThemePath() + "/plugins/" + theName;
    #Attention, ci-dessous, le chemin est � persoonaliser :
    #remplacer "extension" par le nom du r�pertoire de l'extension.
    myQrcPath = "python/plugins/extension/" + theName;
    if QFile.exists(myDefPath): return myDefPath
    elif QFile.exists(myDefPathIcons): return myDefPathIcons
    elif QFile.exists(myCurThemePath): return myCurThemePath
    elif QFile.exists(myDefThemePath): return myDefThemePath
    elif QFile.exists(myQrcPath): return myQrcPath
    elif QFile.exists(theName): return theName
    else: return ""

#Fonction de correction des chemins
#(ajout de slash en fin de cha�ne)
def CorrigePath(nPath):
    nPath = str(nPath)
    a = len(nPath)
    subC = "/"
    b = nPath.rfind(subC, 0, a)
    if a != b : return (nPath + "/")
    else: return nPath
