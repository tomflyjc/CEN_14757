# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Fichier des fonctions du plugin CEN 14757
                                 A QGIS plugin
 Cette Extension pour QGIS 2 etablit un plan d'échantillonnage piscicole
 à l'aide de filets multimaillants selon la norme CEN 14757
                              -------------------
        begin                : 2015-05-01
        copyright            : (C) 2019 by Jean-Christophe Baudin AF Biodiversite DIR9
                               
        email                : jean-christophe.baudin@onema.fr
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""


# Import libs 
import timeit, math, sys, os.path; sys.path.append(os.path.dirname(os.path.abspath(__file__)))
import os, shutil, tempfile
import csv 
import re
import unicodedata
from random import random
from osgeo import ogr
from math import sqrt


from qgis.PyQt.QtWidgets import QMessageBox,QDialog, QDialogButtonBox,QAction,QLabel,QComboBox,QPushButton
# Initialize Qt resources from file resources.py
from PyQt5 import QtCore
from PyQt5 import QtGui
from qgis.core import *
from qgis.gui import *
from qgis.gui import QgsMapCanvas,QgsMessageBar
from qgis.utils import iface

import shapely
from shapely.geometry import Point, LineString, Polygon,MultiPolygon
from shapely.wkt import  dumps,loads
from shapely.ops import cascaded_union




def getVectorLayerByName(NomCouche):
    #layermap=QgsMapLayerRegistry.instance().mapLayers()
    layermap=QgsProject.instance().mapLayers()
    #QMessageBox.information(None,"information:","layermap "+ str(layermap))
    # https://stackoverflow.com/questions/35407560/attributeerror-dict-object-has-no-attribute
    for name, layer in layermap.items():
        if layer.type()==QgsMapLayer.VectorLayer and layer.name()==NomCouche:
            if layer.isValid():
               return layer
            else:
               return None
     
def ouvre_csv_abaque(input_file):
    """ Ouvre le fichier csv contenant l'Abaque de répartition des filets multimailles benthiques
    selon les superficies et profondeurs et stocke ce  résultat dans un dictionnaire de données DictPlanEchant
    """
    try:
        if sys.version > '3':
            reader = csv.reader(open(input_file, 'r', newline='', encoding='iso8859-1'), delimiter=';', quotechar=',')
        else:
            reader = csv.reader(open(input_file, 'rb'), delimiter=';', quotechar=',')
              
    except:
        return "Erreur : fichier d'abaque de répartition des filets introuvable", {}
    
    try:
        DictPlanEchant={}
        with open(input_file, 'rb') as csvfile:
                for ligne in reader:
                     # ligne[0]=id, ligne[1]=superficie, 2= nomSuperficie, 3=ProfondeurMax, 4=NomProfMax,
                     # 5=NbFilets_Strate_0_3, 6=NbFilets_Strate_3_6, 7=NbFilets_Strate_6_11.9,
                     # 8=NbFilets_Strate_12_19.9, 9=NbFilets_Strate_20_34.9, 
                     # 10=NbFilets_Strate_35_49.9, 11=NbFilets_Strate_50_74.9, 12=NbFilets_StrateSup_75,
                     # 13=Nb_Filets,
                     # 14=NomStr_0_3, 15=NomStr_3_5.9, 16=NomStr_6_11.9,
                     # 17=NomStr_12_19.9, 18=NomStr_20,34.9, 19=NomStr_35,49.9,
                     # 201=NomStr_50,74.9,  21=NomStr_sup75
                     DictPlanEchant[ligne[0]]=[ligne[1],ligne[2],ligne[3],ligne[4],ligne[5],ligne[6],ligne[7],ligne[8],ligne[9],ligne[10],ligne[11],ligne[12],ligne[13],ligne[14],ligne[15],ligne[16],ligne[17],ligne[18],ligne[19],ligne[20],ligne[21]]
                   
        csvfile.close()
        return "OK", DictPlanEchant
    except: #return false (erreur) si il y a problème
        return "Erreur: lecture du fichier impossible", {}
    
def ClasseProf(LayerSurf,LayerLigne):
    LayerSurf.startEditing()
    for featS in LayerSurf.getFeatures():
        geomS=featS.geometry()
        LSurf = loads(geomS.asWkt())
        S=LineString(LSurf.exterior.coords)
        fid=featS.id()
        #QMessageBox.information(None,"information:","lecture de S exterior "+ str(S))
        for featL in LayerLigne.getFeatures():
            geomL=featL.geometry()
            LSurf2 = loads(geomL.asWkt())
            #L = LineString(LSurf2.exterior.coords) for polygon
            L = LineString(LSurf2.coords) 
            #QMessageBox.information(None,"information:","lecture LLIGNE WKB "+ str(LLigne))
            if S.equals(L):
                LayerSurf.changeAttributeValue(fid,0,str(featL[0]))
    LayerSurf.commitChanges()            
    return LayerSurf
    
def maxProf1(layerP):
    maxProf=0
    S_id=0
    first=True
    for featP in layerP.getFeatures():
        Prof=featP["Strates"]
        #Id_x=featP[0]
        Id_x=featP.id()
        if first:
            maxProf,S_id,first = Prof,Id_x,False
        else:
            if int(Prof) > int(maxProf):
                maxProf=Prof
                S_id=Id_x
            #QMessageBox.information(None,"information:","maxprof temp "+ str(maxProf))
    #QMessageBox.information(None,"information:","lecture classe maxprof finale "+ str(maxProf))
    return maxProf

def maxProf2 (layerP):
    maxProf=0
    S_id=0
    first=True
    for featP in layerP.getFeatures():
        Prof=featP["profondeur"]
        #Id_x=featP[0]
        Id_x=featP.id()
        if first:
            maxProf,S_id,first = Prof,Id_x,False
        else:
            if int(Prof) > int(maxProf):
                maxProf=Prof
                S_id=Id_x
            #QMessageBox.information(None,"information:","maxprof temp "+ str(maxProf))
    #QMessageBox.information(None,"information:","lecture classe maxprof finale "+ str(maxProf))
    return maxProf

def maxSurf(layerP):
    maxSurf=0
    S_id=0
    first=True
    for featP in layerP.getFeatures():
        Surf=featP["area"]
        #Id_x=featP[0]
        Id_x=featP.id()
        if first:
            maxSurf,S_id,first = Surf,Id_x,False
        else:
            if int(Surf) > int(maxSurf):
                maxSurf=Surf
                S_id=Id_x
            #QMessageBox.information(None,"information:","maxprof temp "+ str(maxProf))
    #QMessageBox.information(None,"information:","lecture classe maxprof finale "+ str(maxProf))
    return maxSurf

def supprIle(Layer1):
    provider=Layer1.dataProvider()
    maxPeri=0
    IDMax=0
    first=True
    for feat1 in Layer1.getFeatures():
        Peri1=feat1["perimeter"]
        idf=feat1.id()
        if first:
            maxPeri,IDMax,first =  Peri1,idf,False
        else:
            if Peri1 > maxPeri:
                maxPeri=Peri1
                IDMax=idf
    #QMessageBox.information(None,"information:","lecture "+ str(IDMax))
    for feat1 in Layer1.getFeatures():
        if feat1[0]==0: 
            if feat1.id()!= IDMax:
                fid1=feat1.id()   
                Layer1.startEditing()
                provider.deleteFeatures([fid1])
                Layer1.commitChanges()
    return Layer1

def GroupStrates(layerP):
    
    LayerF= QgsVectorLayer("MultiPolygon", "Surfaces_uniques_par_classe_de_profondeur", "memory")
    QgsMapLayerRegistry.instance().addMapLayer(LayerF)
    prLayerF = LayerF.dataProvider()
    prLayerF.addAttributes([ QgsField("Strates", QVariant.Int),
                              QgsField("Group_Surf", QVariant.Double),
                              QgsField("Group_Peri", QVariant.Double),
                              QgsField("Nb_Surf", QVariant.Int)])
    
    DicoLayerP={}
    compteur=0
    for featP in layerP.getFeatures():
        geomP=featP.geometry()
        polyP = loads(geomP.asWkt()) 
        ProfP=int(featP["profondeur"])
        AreaP=featP["area"]
        PeriP=featP["perimeter"]
        DicoLayerP[compteur]=[ProfP,AreaP,PeriP,polyP] 
        compteur=compteur+1
    #QMessageBox.information(None,"DEBUG", str(DicoLayerP))    
   
    List=[]
    for key in DicoLayerP.keys():
        if DicoLayerP[key][0] in List:
            pass
        else:
            List.append(DicoLayerP[key][0])
    List.sort()
    #QMessageBox.information(None,"DEBUG", str(List))
    
    DicoF={}
    for P in List:
        S=per=n=0
        polygons=None
        for key in DicoLayerP.keys():
            if DicoLayerP[key][0]==P:
                if n==0:
                    S=S+DicoLayerP[key][1]
                    per=per+DicoLayerP[key][2]
                    n=n+1
                    polygons=DicoLayerP[key][3]
                else:
                    S=S+DicoLayerP[key][1]
                    per=per+DicoLayerP[key][2]
                    n=n+1
                    polygons=polygons.union(DicoLayerP[key][3])
                    #QMessageBox.information(None,"DEBUG", str(polygons))
        DicoF[P]=[P,S,per,n,polygons]
    #QMessageBox.information(None,"DEBUG", str(DicoF))
    for key in DicoF.keys():
        geomF=QgsGeometry.fromWkt(dumps(DicoF[key][4]))
        newfeat = QgsFeature()
        newfeat.setGeometry(geomF)
        Values= []
        Values.append(DicoF[key][0])
        Values.append(DicoF[key][1])
        Values.append(DicoF[key][2])
        Values.append(DicoF[key][3])
        #QMessageBox.information(None,"DEBUG", str(Values))
        newfeat.setAttributes(Values)
        #bascule en mode édition- comme icône crayon  :
        LayerF.startEditing()
        # ce qui suit ajoute les géom et valeurs des enregistrements,
        prLayerF.addFeatures([ newfeat ])
        # même effet que: LayerF.addFeature(newfeat,True)
        #Quitte le mode édition et enregistre les modifs:
        LayerF.commitChanges()
    iface.mapCanvas().refresh()
    
def PlanEch(Pmaxi,surfEau,dico):
	# La fonction PlanEch, parcourt l'abaque dans sa forme de dictionnaire en focntion de Pamxi et Surfeau
	# La focntion traduit Pamxi et Surf Eau en valeur correspondnates à celles du dictionnaire dico de l'abaque
	# La fonction construit alors le dictionnaire Plan dont les clés sont les 8 strates de profondeurs
	# le dictionnaire Plan stocke les valeurs  nb de filet et le nom de la strate
	#
    Plan={}
    NbFilet=0
    if surfEau>=1001:
        surfEau=5000
    elif surfEau>=251:
        surfEau=1000
    elif surfEau>=101:
        surfEau=250
    elif surfEau>=51:
        surfEau=100
    elif surfEau>=21:
        surfEau=50
    elif surfEau>0.01:
        surfEau=20
    else:
        QMessageBox.information(None,"information:","Vérifier la surperficie en eau du lac elle est infèrieure à 100m2 !!! ")
    # modif des profondeurs pour correspondre à celle de l'abaque
    #QMessageBox.information(None,"information:","VerifPmaxi entree"+ str(Pmaxi))
    if int(Pmaxi)==3:
        Pmaxi=6
    elif int(Pmaxi)==6:
        Pmaxi=12
    elif int(Pmaxi)==12:
        Pmaxi=20
    elif int(Pmaxi)==20:
        Pmaxi=35
    elif int(Pmaxi)==35:
        Pmaxi=50
    elif int(Pmaxi)==50:
        Pmaxi=75
    elif int(Pmaxi)==75:
        Pmaxi=10000
    #QMessageBox.information(None,"information:","Verif Pmaxi modif"+ str(Pmaxi)+ "\n")
    
    for key in dico.keys():
        if str(surfEau) ==dico[key][0]:
            if str(Pmaxi)==dico[key][2]:
                #QMessageBox.information(None,"information:","id:"+ str(key)+ "\n"+" surf: " + str(dico[key][0])+ "\n"+ "prof: "+ str(dico[key][2]))
                NbFilet=dico[key][12]
                for i in range(8):
                    Plan[i]=[dico[key][i+4],dico[key][i+13]]
                    #QMessageBox.information(None,"information:", " strate: " + str(Plan[i][1])+"\n"+ "nb filets " + str(Plan[i][0]))
    #QMessageBox.information(None,"information:", " NBF: " + str(NbFilet)+ "\n"+ " surf: "+ str(Plan))    
    return Plan,NbFilet

# Convinience function to create a spatial index for input QgsVectorDataProvider
def createIndex( provider ):
    feat = QgsFeature()
    index = QgsSpatialIndex()
    fit = provider.getFeatures()
    while fit.nextFeature( feat ):
        index.insertFeature( feat )
    return index


def vectorTirRandom(n, layer, xmin, xmax, ymin, ymax):
    provider = layer.dataProvider()
    index = createIndex(provider)
    points = []
    feat = QgsFeature()
    i = 1
    while i <= n:
        point = QgsPoint(xmin + (xmax-xmin) * random(), ymin + (ymax-ymin) * random())
        pGeom = QgsGeometry().fromPoint(point)
        ids = index.intersects(pGeom.buffer(5,5).boundingBox())
        for id in ids:
            provider.getFeatures( QgsFeatureRequest().setFilterFid( int(id) ) ).nextFeature( feat )
            tGeom = QgsGeometry(feat.geometry())
            if pGeom.intersects(tGeom):
                points.append(pGeom)
                i = i + 1
                break
    for p in points:
        Pf=p
    return Pf


def TiragePoint(j,Gs,Tirage,Ti,Vrai):
    r=Gs.bounds
    # Shapley function bounds return (minx,miny,maxx,maxy)tuple
    xmin=r[0]
    xmax=r[2]
    ymin=r[1]
    ymax=r[3]
    point = Point((xmin + (xmax-xmin) * random()), (ymin + (ymax-ymin) * random()))
    while point.within(Gs)==False:
        point = Point((xmin + (xmax-xmin) * random()), (ymin + (ymax-ymin) * random()))
    #QMessageBox.information(None,"information:", "debug Tirage Point: "  +str(point)+"\n"+ " xmin:"+ str(xmin)+"\n"+ " jour:"+ str(j))
    if Vrai:
        Vrai=False
        Tirage[Ti]=[point,j]
    else:
        #QMessageBox.information(None,"information:", "debug in Tirage Point5: "  +str(Vrai))
        d=0
        compteurM=0
        for tc in Tirage.keys():
            compteurM+=1
        #QMessageBox.information(None,"information:", "compteur debut M: "  +str(compteurM))    
        compt=0
        while compt<=compteurM:
            for t in Tirage.keys():
                compt+=1
                p=Tirage[t][0]
                d=point.distance(p)
                if j==Tirage[t][1]:
				#D 200
                    while (d <= 110) or (point.within(Gs)== False):
                        point = Point((xmin + (xmax-xmin) * random()), (ymin + (ymax-ymin) * random()))
                        d=point.distance(p)
                        #QMessageBox.information(None,"information:", "debug distance inf 200: "  + str(d))    
                        compt=0     
                else:
                    while (d <= 100) or (point.within(Gs)== False):
                        point = Point((xmin + (xmax-xmin) * random()), (ymin + (ymax-ymin) * random()))
                        d=point.distance(p)
                        #QMessageBox.information(None,"information:", "debug distance inf 100: "  + str(d))
                        compt=0     
           
            #QMessageBox.information(None,"information:", "compt: "  +str(compt))
        Tirage[Ti]=[point,j]
    return point,Vrai,Tirage

def Echantillonne(NBF,Plan,liste,layerW):
    
    #layerW=getVectorLayerByName(layerWname)
    #QMessageBox.information(None,"information:", "debug: "  +str(NBF)+"\n"+ str(Plan)+"\n"+ str(liste)+"\n"+ str(layerW))
    # on crée à partir de liste: la liste des nbs de filest par jour de pose un dictionnaire  "DicoNbfiletJour"
    # avec donc DicoNbfiletJour[0]=nb de filet du jour 1, DicoNbfiletJour[1]=nb de filet du jour 2, etc
    DicoNbfiletJour={}
    i=0
    for nbj in liste:
         DicoNbfiletJour[i]=[nbj]
         i+=1
    #QMessageBox.information(None,"DEBUG_DicoNbfiletJour", str(DicoNbfiletJour))
    
    #C onstruction du dictionnaire DicoJ des échantillons / des points de pose
    # Ce dictionnaire stocke le "tableau" de pose.
    # Les clefs de DicoJ sont le numéros des points de pose
    # Pour chaque point de pose ,DicoJ contient (jour,n°du point de pose du jour,n°strate,nom strate,X,Y)
    DicoJ={}
    f=1 # f comme filets, c'est le n° du point de pose
    # f sera égal à NBF, il est atteind quand on a posé le nb de filets prévu chaque jour
    # nbfj c'est le nb de filet du jour
    # key c'est la clé qui parcourt Plan, Plan est le dictionnaire des nb de filets par strates
    nbfj=0
    stra=0
    key_strate=0
    jour=0
    nb_filet_qui_reste_a_poser=0
    X=Y=0.9 # valeurs temporaire des coordonnées du point
    PointGeom=[]
    PointGeom=""
    for j in DicoNbfiletJour.keys():
        # pour le jour de pose donné, on  va incrémenter jusqu'au nb de filet du jour...
        for nbfj in range(DicoNbfiletJour[j][0]):
            # on va parcourir avec key les 8 strates numérotées de 0 à 7
            # si le nb de filet à poser dans Plan est null pour cette strate on passe à la suivante jusqu'à trouver un filet à poser
            nb_filet_qui_reste_a_poser=int(Plan[key_strate][0])
            while nb_filet_qui_reste_a_poser==0:
                key_strate+=1
                # si on a atteind la dernière strate on repart à la première
                # if key_strate>=7:key_strate=0
                # probleme
                if key_strate>7:key_strate=0
                nb_filet_qui_reste_a_poser=int(Plan[key_strate][0])
            #on traduit les strates de 0 à 7 en prof max
            if key_strate==0:stra=0
            elif key_strate==1:stra=3
            elif key_strate==2:stra=6
            elif key_strate==3:stra=12
            elif key_strate==4:stra=20
            elif key_strate==5:stra=35
            elif key_strate==6:stra=50
            elif key_strate==7:stra=75
            DicoJ[f]=[j+1,nbfj+1,stra,Plan[key_strate][1],X,Y,PointGeom]
            # Quand un filet est placé dans une strate,
            # le nb de filet à poser dans la strate diminue de 1 dans Plan
            Plan[key_strate][0]=str(int(Plan[key_strate][0])-1)
            key_strate+=1
            # quand on atteind la dernière strate on repart à la première
            if key_strate>=7:key_strate=0
            #if int(Plan[key_strate][0]!=0):Plan[key_strate][0]=str(int(Plan[key_strate][0])-1)
            f+=1
            
            # key_nb_filets_strate+=1
    #QMessageBox.information(None,"DEBUG_dicoJ", str(DicoJ))
    
    TirageEncours={}
    T=0
    first=True
    for e in DicoJ.keys():
        for featW in layerW.getFeatures():
            geomW=featW.geometry()
            G=loads(geomW.asWkt())
            if int(DicoJ[e][2])== int(featW["profondeur"]):
                r=G.bounds
                # Shapley function bounds return (minx,miny,maxx,maxy)tuple
                xmin=r[0]
                xmax=r[2]
                ymin=r[1]
                ymax=r[3]
                #vectorTirRandom function de tirage aléatoire de point avec conditions
                #Pt=vectorTirRandom(1, layerW, xmin, xmax, ymin, ymax)
                Pt,first,TirageEncours=TiragePoint(int(DicoJ[e][0]),G,TirageEncours,T,first)
                #QMessageBox.information(None,"DEBUG_sortie tirage pt", str(Pt)+str(first)+"\n"+str(TirageEncours))
                T=T+1
                x=Pt.x
                y=Pt.y
                DicoJ[e][4]=("{0:.2f}".format(x))
                DicoJ[e][5]=("{0:.2f}".format(y))
                DicoJ[e][6]=dumps(Pt)
                """
                Gp=loads(Pt.asWkt())
                DicoJ[e][4]=("{0:.2f}".format(Gp.x))
                DicoJ[e][5]=("{0:.2f}".format(Gp.y))
                DicoJ[e][6]=dumps(Point(Gp.x,Gp.y))
                """
    return DicoJ
    
    
    
    


   
    
