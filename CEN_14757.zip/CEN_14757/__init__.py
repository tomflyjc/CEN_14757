# (c) JC BAUDIN 2018 Version 4.0 pour QGIS 3
# jean-christophe.baudin@afbiodiversite.fr 
def classFactory(iface):
  from .CEN_14757 import MainPluginCEN
  return MainPluginCEN(iface)

