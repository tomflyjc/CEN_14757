# -*- coding: utf-8 -*-
from PyQt5 import QtCore
from PyQt5.QtGui import *
#from qgis.PyQt.QtCore import QtCore	
from qgis.PyQt.QtWidgets import QMessageBox,QDialog, QDialogButtonBox,QAction,QGridLayout,QLabel,QTextEdit,QPushButton,QFrame,QSpacerItem,QSizePolicy,QApplication
# Import libs 
import timeit, math, sys, os.path; sys.path.append(os.path.dirname(os.path.abspath(__file__)))


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(QtCore.QSize(QtCore.QRect(0,0,330,350).size()).expandedTo(Dialog.minimumSizeHint()))

        self.gridlayout = QGridLayout(Dialog)
        self.gridlayout.setObjectName("gridlayout")
        
        self.label_2 = QLabel(Dialog)
              
        font = QFont()
        font.setPointSize(15) 
        font.setWeight(50) 
        font.setBold(True)
        self.label_2.setFont(font)
        self.label_2.setTextFormat(QtCore.Qt.RichText)
        self.label_2.setObjectName("label_2")
        self.gridlayout.addWidget(self.label_2,1,1,1,2)
               
        self.textEdit = QTextEdit(Dialog)

        palette = QPalette()

        brush = QBrush(QColor(0,0,0,0))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QPalette.Active,QPalette.Base,brush)

        brush = QBrush(QColor(0,0,0,0))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QPalette.Inactive,QPalette.Base,brush)

        brush = QBrush(QColor(255,255,255))
        brush.setStyle(QtCore.Qt.SolidPattern)
        palette.setBrush(QPalette.Disabled,QPalette.Base,brush)
        self.textEdit.setPalette(palette)
        self.textEdit.setAutoFillBackground(True)
        self.textEdit.width = 320
        self.textEdit.height = 380
        self.textEdit.setFrameShape(QFrame.NoFrame)
        self.textEdit.setFrameShadow(QFrame.Plain)
        self.textEdit.setReadOnly(True)
        self.textEdit.setObjectName("textEdit")
        self.textEdit.setTextInteractionFlags(QtCore.Qt.TextBrowserInteraction)
       
        self.gridlayout.addWidget(self.textEdit,2,1,5,2) 

        self.pushButton = QPushButton(Dialog)
        self.pushButton.setObjectName("pushButton")
        self.gridlayout.addWidget(self.pushButton,4,2,1,1) 

        spacerItem = QSpacerItem(20,40,QSizePolicy.Minimum,QSizePolicy.Expanding)
        self.gridlayout.addItem(spacerItem,3,1,1,1)

        self.retranslateUi(Dialog)
        self.pushButton.clicked.connect(Dialog.reject)
        # QtCore.QObject.connect(self.pushButton,QtCore.SIGNAL("clicked()"),Dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(QApplication.translate("Dialog", "CEN 14757", None))
        self.label_2.setText(QApplication.translate("Dialog", "Générateur de plan d'échantillonnage plan d'eau", None))
        self.textEdit.setHtml(QApplication.translate("Dialog", "<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
        "p, li { white-space: pre-wrap; }\n"
        "</style></head><body style=\" font-family:\'Sans Serif\'; font-size:8pt; font-weight:400; font-style:normal;\">\n"
        "<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:\'MS Shell Dlg 2\'; font-size:8pt;\"><span style=\" font-weight:600;\">"
        "Plugin CEN 14757:</span>" "  Cette extension  est conçue pour fournir un plan d'échantillonnage piscicole à l'aide de filets multimailles selon la norme CEN 14757 .                                                                                        "+
                                                           " Il génère une couche de points de pose des filets benthiques en fonction d'un nombre de filets par jour de pose fixé par l'utilisateur." +
                                                           " Pour le faire fonctionner, la ''clé d'entrée'' est une couche bathymétrique composée de polygones dont la table attributaire contient un unique champ qui doit être nommé ''profondeur'', et dont les valeurs sont:                                                                                                                     "+
                                                           "- 0 pour le contour du lac (NB:le polygone peut être ''troué'' par des iles),                                                                                                                            "+
                                                           "- 3 pour la ligne à partir de laquelle la prodondeur de 3 mètres est atteinte,                                                                                                                                               "+
                                                           "- 6 pour la ligne à partir de laquelle la prodondeur de 6 mètres est atteinte,                                                                                                                                               "+
                                                           "- 12 pour la ligne à partir de laquelle la prodondeur de 12 mètres est atteinte,                                                                                                                                               "+
                                                           "- et ainsi de suites… (ne mettre que les valeurs de profondeur de l'abaque de la norme, et pas de valeurs intermédiaires (comme: 1 m, 2 m).                                     "+
                                                           "                                                                                                                                                                          "+
                                                          " Cette extension ne fait pas partie du moteur de Qgis et tout probleme ne peut être adressé aux développeurs QGIS, mais à l'auteur: </p></td></tr></table>"
        "<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"></p>\n"
        "<p style=\"margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">"
        #"<font color='#0000FF'><b><u> Jean-Christohe Baudin</u></b></font><br><br>"
        "<b>AF biodiversite DIR9 </b><br><b>jean-christophe.baudin@afbiodiversite.fr</b><br>"
        "<br><br><i>code 4 (10 janvier 2019).</i></p></body></html>", None))
        self.pushButton.setText(QApplication.translate("Dialog", "OK", None))

