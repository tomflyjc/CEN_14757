# -*- coding: iso-8859-1 -*-
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *
from qgis.gui import QgsMessageBar
from qgis.utils import iface
from qgis.core import *
from PyQt5 import QtCore
from PyQt5.QtGui import *
#from PyQt5.QtGui import QLabel,QComboBox,QPushButton	
from qgis.PyQt.QtWidgets import QMessageBox,QDialog,QProgressBar,QDialogButtonBox,QAction,QLabel,QComboBox,QPushButton,QLineEdit,QApplication
# Initialize Qt resources from file resources.py
#QVBoxlayout
# Import libs 
import timeit, math, sys, os.path; sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import shapely
from shapely.geometry import Point, LineString, Polygon, MultiPolygon
from shapely.wkt import dumps, loads
from shapely import *

import os.path
import os
import fonctionsCEN_14757
import doAbout



class Ui_Dialog(object):
    """
    def __init__(self, iface):
        self.iface = iface
    """
    def setupUi(self, Dialog):
        largeur=330
        hauteur=620
        self.iface = iface
        Dialog.setObjectName("Dialog")
        Dialog.resize(QtCore.QSize(QtCore.QRect(0,0, largeur,hauteur).size()).expandedTo(Dialog.minimumSizeHint()))
        Dialog.setWindowTitle("G�n�rateur de plans d'�chantillonnage lac ")
        
	# QLabel de couche Polygon
        self.label = QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(15,10,280,23))
        self.label.setObjectName("label")
        self.label.setText("<u>S�lectionner la couche des isobathes :</u>")

        ListeCouchesPolygon=[""]
        NbCouches=self.iface.mapCanvas().layerCount()
        if NbCouches==0: QMessageBox.information(None,"information:","Pas de couches ! ")
        else:
            for i in range(0,NbCouches):
                couche=self.iface.mapCanvas().layer(i)
                # 1 pour Polygon, 2 pour polygone
                if couche.geometryType()== 2:
                    if couche.isValid():
                       ListeCouchesPolygon.append(couche.name())
                    else:
                       QMessageBox.information(None,"information:","pas de couches d'objets polygones")
                       return None
                    
        self.ComboBoxPolygons = QComboBox(Dialog)
        self.ComboBoxPolygons.setMinimumSize(QtCore.QSize(300, 25))
        self.ComboBoxPolygons.setMaximumSize(QtCore.QSize(300, 25))
        self.ComboBoxPolygons.setGeometry(QtCore.QRect(10, 40, 300,25))
        self.ComboBoxPolygons.setObjectName("ComboBoxPolygons")
        for i in range(len(ListeCouchesPolygon)):  self.ComboBoxPolygons.addItem(ListeCouchesPolygon[i])

        #Exemple de QPushButton
        self.DoButton = QPushButton(Dialog)
        self.DoButton.setMinimumSize(QtCore.QSize(200, 20))
        self.DoButton.setMaximumSize(QtCore.QSize(200, 20))        
        self.DoButton.setGeometry(QtCore.QRect(60,80, 200, 20))
        self.DoButton.setObjectName("DoButton")
        self.DoButton.setText(" Lancer la lecture de l'abaque !")


        # QLabel entrer le nb de filets par jour
        self.labelnbfilets = QLabel(Dialog)
        self.labelnbfilets.setGeometry(QtCore.QRect(15,125,300,20))
        self.labelnbfilets.setObjectName("labelnbfilets")
        self.labelnbfilets.setText("<u> La norme pr�conise un nombre de filets = </u>")

        #QLabel pose NBF
        self.labelNBF = QLabel(Dialog)
        self.labelNBF.setGeometry(QtCore.QRect(225,125,90,20))
        self.labelNBF.setObjectName("labelNBF")
        self.labelNBF.setText("<u>non encore calcul� </u>")
        
        # QLabel entrer le nb de filets par jour
        self.labelPmax = QLabel(Dialog)
        self.labelPmax.setGeometry(QtCore.QRect(15,155,300,20))
        self.labelPmax.setObjectName("labelPmax")
        self.labelPmax.setText("<u> Renseigner le nombre de filets par journ�e de pose :</u>")
        
        #QLabel pose J1
        self.labeJ1 = QLabel(Dialog)
        self.labeJ1.setGeometry(QtCore.QRect(15,185,90,18))
        self.labeJ1.setObjectName("labelJ1")
        self.labeJ1.setText("<u>Jour 1: </u>")
        
        self.TextEditJ1 = QLineEdit(Dialog)
        self.TextEditJ1.setMinimumSize(QtCore.QSize(50, 20))
        self.TextEditJ1.setMaximumSize(QtCore.QSize(50, 20))
        self.TextEditJ1.setGeometry(QtCore.QRect(110, 185, 50,20))
        self.TextEditJ1.setObjectName("TextEditJ1")
       
        #QLabel pose J2
        self.labeJ2 = QLabel(Dialog)
        self.labeJ2.setGeometry(QtCore.QRect(15,215,90,18))
        self.labeJ2.setObjectName("labelJ2")
        self.labeJ2.setText("<u>Jour 2: </u>")
        
        self.TextEditJ2 = QLineEdit(Dialog)
        self.TextEditJ2.setMinimumSize(QtCore.QSize(50, 20))
        self.TextEditJ2.setMaximumSize(QtCore.QSize(50, 20))
        self.TextEditJ2.setGeometry(QtCore.QRect(110,215,50,20))
        self.TextEditJ2.setObjectName("TextEditJ2")

        #QLabel pose J3
        self.labeJ3 = QLabel(Dialog)
        self.labeJ3.setGeometry(QtCore.QRect(15,245,90,18))
        self.labeJ3.setObjectName("labelJ3")
        self.labeJ3.setText("<u>Jour 3: </u>")
        
        self.TextEditJ3 = QLineEdit(Dialog)
        self.TextEditJ3.setMinimumSize(QtCore.QSize(50, 20))
        self.TextEditJ3.setMaximumSize(QtCore.QSize(50, 20))
        self.TextEditJ3.setGeometry(QtCore.QRect(110,245, 50,20))
        self.TextEditJ3.setObjectName("TextEditJ3")

        #QLabel pose J4
        self.labeJ4 = QLabel(Dialog)
        self.labeJ4.setGeometry(QtCore.QRect(15,275,90,18))
        self.labeJ4.setObjectName("labelJ4")
        self.labeJ4.setText("<u>Jour 4: </u>")
        
        self.TextEditJ4 = QLineEdit(Dialog)
        self.TextEditJ4.setMinimumSize(QtCore.QSize(50, 20))
        self.TextEditJ4.setMaximumSize(QtCore.QSize(50, 20))
        self.TextEditJ4.setGeometry(QtCore.QRect(110,275,50,20))
        self.TextEditJ4.setObjectName("TextEditJ4")

        #QLabel pose J5
        self.labeJ5 = QLabel(Dialog)
        self.labeJ5.setGeometry(QtCore.QRect(15,305,90,18))
        self.labeJ5.setObjectName("labelJ5")
        self.labeJ5.setText("<u>Jour 5: </u>")
        
        self.TextEditJ5 = QLineEdit(Dialog)
        self.TextEditJ5.setMinimumSize(QtCore.QSize(50, 20))
        self.TextEditJ5.setMaximumSize(QtCore.QSize(50, 20))
        self.TextEditJ5.setGeometry(QtCore.QRect(110,305,50,20))
        self.TextEditJ5.setObjectName("TextEditJ5")

        #QLabel pose J6
        self.labeJ6 = QLabel(Dialog)
        self.labeJ6.setGeometry(QtCore.QRect(15,335,90,18))
        self.labeJ6.setObjectName("labelJ6")
        self.labeJ6.setText("<u>Jour 6: </u>")
        
        self.TextEditJ6 = QLineEdit(Dialog)
        self.TextEditJ6.setMinimumSize(QtCore.QSize(50, 20))
        self.TextEditJ6.setMaximumSize(QtCore.QSize(50, 20))
        self.TextEditJ6.setGeometry(QtCore.QRect(110,335,50,20))
        self.TextEditJ6.setObjectName("TextEditJ6")
        
        self.ENTER = QPushButton(Dialog)
        self.ENTER.setMinimumSize(QtCore.QSize(200, 20))
        self.ENTER.setMaximumSize(QtCore.QSize(200, 20))        
        self.ENTER.setGeometry(QtCore.QRect(60,385, 200, 20))
        self.ENTER.setObjectName("ENTER")
        self.ENTER.setText("Valider et lancer les calculs")
        
        
        #Exemple de ProgressBar
        self.progressBar = QProgressBar(Dialog)
        self.progressBar.setProperty("value", 0)
        self.progressBar.setMinimumSize(QtCore.QSize(260, 15))
        self.progressBar.setMaximumSize(QtCore.QSize(260, 15))
        self.progressBar.setGeometry(QtCore.QRect(30,455,260,15))
        self.progressBar.setAlignment(QtCore.Qt.AlignCenter)
        self.progressBar.setTextVisible(True)
        self.progressBar.setObjectName("progressBar")
        self.progressBar.setStyleSheet(
            """QProgressBar {border: 2px solid grey; border-radius: 5px; text-align: center;}"""
            """QProgressBar::chunk {background-color: #6C96C6; width: 20px;}"""
            )
        #Pose a minima une valeur de la barre de progression / slide contr�le
        self.progressBar.setValue(0)

        # Panneau Pub !
        self.label_2 = QLabel(Dialog)
        self.labelImage = QLabel(Dialog)
        self.labelImage.setMinimumSize(QtCore.QSize(300,100))
        self.labelImage.setMaximumSize(QtCore.QSize(300,100))        
        self.labelImage.setGeometry(QtCore.QRect(30, 480, 300,100))
        myPath = os.path.dirname(__file__)+"/data/logo_afb.png";
        myDefPath = myPath.replace("\\","/");
        carIcon = QImage(myDefPath)
        self.labelImage.setPixmap(QPixmap.fromImage(carIcon))
        
        #Exemple de QPushButton
        self.CloseButton = QPushButton(Dialog)
        self.CloseButton.setMinimumSize(QtCore.QSize(100, 20))
        self.CloseButton.setMaximumSize(QtCore.QSize(100, 20))        
        self.CloseButton.setGeometry(QtCore.QRect(185, 590,100, 20))
        self.CloseButton.setObjectName("CloseButton")
        self.CloseButton.setText(" Quitter !")
        
        #Exemple de QPushButton
        self.aboutButton = QPushButton(Dialog)
        self.aboutButton.setMinimumSize(QtCore.QSize(70, 20))
        self.aboutButton.setMaximumSize(QtCore.QSize(70, 20))        
        self.aboutButton.setGeometry(QtCore.QRect(30, 590, 70, 23))
        self.aboutButton.setObjectName("aboutButton")
        self.aboutButton.setText(" A propos...")

        # Connexion des slots et des actions li�es
         #self.about.triggered.connect(self.doInfo)
        self.CloseButton.clicked.connect(Dialog.reject)
        self.ComboBoxPolygons.activated[str].connect(self.onComboL)
        self.ENTER.clicked.connect(self.onComboT)
        self.aboutButton.clicked.connect(self.doAbout)
        self.DoButton.clicked.connect(self.Run)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
        """
        # dans QGIS 2 c etait
        QtCore.QObject.connect(self.CloseButton,QtCore.SIGNAL("clicked()"),Dialog.reject)
        QtCore.QObject.connect(self.ComboBoxPolygons,QtCore.SIGNAL("currentIndexChanged(QString)"),self.onComboL)
        QtCore.QObject.connect(self.ENTER, SIGNAL("clicked()"), self.onComboT)
        QtCore.QObject.connect(self.aboutButton, SIGNAL("clicked()"), self.doAbout)
        QtCore.QObject.connect(self.DoButton, SIGNAL("clicked()"), self.Run)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
        """
        
    def onComboL(self):
        SelectionP = self.ComboBoxPolygons.currentText()
        #QMessageBox.information(None,"information:","couche selectionnee: "+ (SelectionP))
        CoucheP=fonctionsCEN_14757.getVectorLayerByName(SelectionP)
        counterP=0
        for featP in CoucheP.getFeatures():
            counterP+=1
        #QMessageBox.information(None,"information:","La couche_"+ str(CoucheP.name())+" contient: " + str(counterP)+" objets isobathes !")
        if counterP==0:
            QMessageBox.information(None,"information:","La couche_"+ str(CoucheP.name())+" ne contient pas d'objets !")
            
    
    def doAbout(self):
        d = doAbout.Dialog()
        d.exec_()
           
    def Run(self):
        global CoucheP,BATHY
        global PEch,NBF
        
        self.iface = iface
        SelectionP = self.ComboBoxPolygons.currentText()
        CoucheP=fonctionsCEN_14757.getVectorLayerByName(SelectionP)
        zDim=counterP=counterN=counterProgess=0
        indexPoly=QgsSpatialIndex()
        for featP in CoucheP.getFeatures():
            indexPoly.insertFeature(featP)
            counterP+=1
        zDim=counterP=counterN=counterProgess=0
        indexPoly=QgsSpatialIndex()
        for featP in CoucheP.selectedFeatures():
            indexPoly.insertFeature(featP)
            counterP+=1
        Pyramide=QgsVectorLayer("Polygon",  str(CoucheP.name())+"_decoupage_par_strates", "memory")
        #QgsMapLayerRegistry.instance().addMapLayer(Pyramide)
        #https://github.com/minorua/Qgis2threejs/commit/22395333f4acb5ac89e82c28cbf2ec16998c0d80
        QgsProject.instance().addMapLayer(Pyramide)
        prPyramide = Pyramide.dataProvider()
        providerP = CoucheP.dataProvider()
        fieldsP = providerP.fields()
        for f in fieldsP:
            znameField= f.name()
            Type= str(f.typeName())
            if Type == 'Integer': prPyramide.addAttributes([ QgsField( znameField, QVariant.Int)])
            if Type == 'Real': prPyramide.addAttributes([ QgsField( znameField, QVariant.Double)])
            if Type == 'String': prPyramide.addAttributes([ QgsField( znameField, QVariant.String)])
            else : prPyramide.addAttributes([ QgsField( znameField, QVariant.String)])
           
        prPyramide.addAttributes([QgsField("NivEmboit", QVariant.Double),
                                  QgsField("NbInclus", QVariant.Double), QgsField( "PROF", QVariant.String)])
        # NivEmboit= nb de polygone dans lequel il est inclus
        # Nb_Inclus= nb de polygone qu'il contient
        #QMessageBox.information(None,"DEBUG3:", str(nivemboit))
       
        
        for feat1 in CoucheP.getFeatures():
            par=0
            nivemboit=0
            nbinclus=0
            PROF=""
            counterProgess+=1
            geom1=feat1.geometry()
            #https://qgis.org/pyqgis/3.2/core/Point/QgsPoint.html#qgis.core.QgsPoint.asWkb
            #QMessageBox.information(None,"DEBUG3:geom1.asWkt()", str(geom1.asWkt()))
            Pl1 = loads(geom1.asWkt())
            P1=Pl1.buffer(0)
            PFinal=Pl1.buffer(0)
            for feat2 in CoucheP.getFeatures():
                geom2=feat2.geometry()
                Pl2 = loads(geom2.asWkt())
                P2=Pl2.buffer(0)
                if P1.equals(P2):
                    pass
                else:
                    if P1.contains(P2):
                        PFinal=(PFinal.difference(P2))
                        nbinclus+=1
                    # within return  true si l'int�rieur de P1 et sa limite sont dans l'int�rieur de P2             
                    if P1.within(P2):
                        nivemboit+=1
            geomF=QgsGeometry.fromWkt(dumps(PFinal))         
            PROF=str(feat1[0])            
            #QMessageBox.information(None,"DEBUGindex: NIv Emboit ", str(nivemboit))
            newfeat = QgsFeature()
            newfeat.setGeometry(geomF)
            Values=feat1.attributes()
            Values.append(nivemboit)
            Values.append(nbinclus)
            Values.append(PROF)
            newfeat.setAttributes(Values)
            #bascule en mode �dition- comme ic�ne crayon  :
            Pyramide.startEditing()
            # ce qui suit ajoute les g�om et valeurs des enregistrements,
            prPyramide.addFeatures([ newfeat ])
            # m�me effet que: Pyramide.addFeature(newfeat,True)
            #Quitte le mode �dition et enregistre les modifs:
            Pyramide.commitChanges()

        BATHY=QgsVectorLayer("Polygon", "ISOBATHES", "memory")
        QgsProject.instance().addMapLayer(BATHY)
        prBATHY = BATHY.dataProvider()
        fieldsPyr =prPyramide.fields()       
        prBATHY.addAttributes([QgsField( "profondeur", QVariant.Int),QgsField("area", QVariant.Double)])
        #QMessageBox.information(None,"DEBUG3:", str(nivemboit))
        DicoProf={}
        first=True
        counterDicoProf=0
        ListePROF=[]
        c=0
        for feat11 in Pyramide.getFeatures():
            if feat11[0]in ListePROF :pass
            else:
                ListePROF.append(feat11[0])
                counterDicoProf+=1
        area=0
        Pgeom=0
        while c < counterDicoProf:
            DicoProf[c]=[ListePROF[c]]
            DicoProf[c].append(area)
            DicoProf[c].append(Pgeom)
            c+=1
        #QMessageBox.information(None,"DEBUG3:", str(DicoProf))
        first=True
        for D in list(DicoProf.keys()):
            for feat11 in Pyramide.getFeatures():
                geom11=feat11.geometry()
                Pl11 = loads(geom11.asWkt())
                P11=Pl11.buffer(0)
                area=P11.area
                if feat11[0]==DicoProf[D][0]:
                    if DicoProf[D][2]==0:
                        DicoProf[D].remove(DicoProf[D][2])
                        DicoProf[D].remove(DicoProf[D][1])
                        DicoProf[D].append(area)
                        DicoProf[D].append(P11)
                        
                    else:
                        area=area+(DicoProf[D][1])
                        Pgeom=DicoProf[D][2].union(P11)
                        DicoProf[D].remove(DicoProf[D][2])
                        DicoProf[D].remove(DicoProf[D][1])
                        DicoProf[D].append(area)
                        DicoProf[D].append(Pgeom)
                
                   
        #QMessageBox.information(None,"DEBUG3:", str(DicoProf))
        for D in list(DicoProf.keys()):
            geomBATHY=QgsGeometry.fromWkt(dumps(DicoProf[D][2]))         
            areaBATHY=DicoProf[D][1]
            ProfBATHY=DicoProf[D][0]
            #QMessageBox.information(None,"DEBUGindex: NIv Emboit ", str(nivemboit))
            newfeat = QgsFeature()
            newfeat.setGeometry(geomBATHY)
            Values=[ProfBATHY,areaBATHY]
            newfeat.setAttributes(Values)
            #bascule en mode �dition- comme ic�ne crayon  :
            BATHY.startEditing()
            # ce qui suit ajoute les g�om et valeurs des enregistrements,
            prBATHY.addFeatures([ newfeat ])
            # m�me effet que: Pyramide.addFeature(newfeat,True)
            #Quitte le mode �dition et enregistre les modifs:
            BATHY.commitChanges()

             
        myPath = os.path.dirname(__file__)+"/data/AbaqueRepFilets.csv";
        uri = myPath.replace("\\","/")
        #QMessageBox.information(None,"information:","test: "+ str(uri))
        #uri="C:/Program Files/QGIS Dufour/apps/qgis/python/plugins/CEN_14757/data/AbaqueRepFilets.csv"
        erreur, dictPlanEch = fonctionsCEN_14757.ouvre_csv_abaque(uri)
        if erreur=="OK":
            StratPmax=fonctionsCEN_14757.maxProf2(CoucheP)
        #QMessageBox.information(None,"information:","test: "+ str(dictPlanEch))
        #QMessageBox.information(None,"information:","StratPmax: "+ str(StratPmax))
        surftot=0
       	#for featP in zlayerS2.getFeatures():
	   # Surf=featP["area"]
	    #surftot+=Surf
        for fet in BATHY.getFeatures():
            surftot+=fet[1]
            
	# surftot passage de m2 � ha !
        surftot=surftot/10000
        #QMessageBox.information(None,"information:","test surftot: "+ str(surftot))
        #NBF=0
        #PEch={}
        PEch,NBF=fonctionsCEN_14757.PlanEch(StratPmax,surftot,dictPlanEch)
        vald=valc=0
        toto=""
        for i in PEch.keys():
            toto= toto + "- pour la strate "+ str(PEch[i][1])+ " : " +str(PEch[i][0])+ " filets" + "\n"
        QMessageBox.information(None,"information:","La surface en eau du lac est de {0:.2f}".format(surftot)+ " hectares." +"\n"+
                                 "La profondeur maximale d�passe les " +str(StratPmax)+" m�tres."+ "\n"+"\n"+
                                "D'apr�s la norme CEN_14757, il faut d�ployer "  + str(NBF)+ " filets."+ "\n"+ "\n"+
                                "et le plan d'�chantillonnage par strate doit �tre : " + "\n" +"\n"+  str(toto))
        self.labelNBF.setText(str(NBF))
        self.TextEditJ1.setText(str(0))
        self.TextEditJ2.setText(str(0))
        self.TextEditJ3.setText(str(0))
        self.TextEditJ4.setText(str(0))
        self.TextEditJ5.setText(str(0))
        self.TextEditJ6.setText(str(0))
        
        """
        # pour preremplissage automatique des nb filets jours
        vald=(int(NBF)/5)
        valc=(int(NBF)/5)+(int(NBF)%5)
        self.TextEditJ1.setText(str(valc))
        self.TextEditJ2.setText(str(vald))
        self.TextEditJ3.setText(str(vald))
        self.TextEditJ4.setText(str(vald))
        self.TextEditJ5.setText(str(vald))
        """
        
    def onComboT(self):
        self.iface = iface
        ListNBFJour=[]
        S=a=b=c=d=e=f=x=0
        f=int(NBF)
        self.nbFJ1=self.TextEditJ1.text()
        a=int(self.nbFJ1)
        self.nbFJ2=self.TextEditJ2.text()
        b=int(self.nbFJ2)
        self.nbFJ3=self.TextEditJ3.text()
        c=int(self.nbFJ3)
        self.nbFJ4=self.TextEditJ4.text()
        d=int(self.nbFJ4)
        self.nbFJ5=self.TextEditJ5.text()
        e=int(self.nbFJ5)
        self.nbFJ6=self.TextEditJ6.text()
        x=int(self.nbFJ6)
        S=(a+b+c+d+e+x)
        ListNBFJour=[a,b,c,d,e,x]
        if S!=f:
            QMessageBox.information(None,"information:","Vous proposez un total de "+ str(S)+" filets, corrigez pour atteindre "+ str(f))
        else:
            #CounterEssais=0
            # try CounterEssais < 100 000:
            #def doDlgBox2(self):
            #   d2 = doDlgBox2.Dialog()
            #   d2.exec_()
            #CoucheSURF=fonctionsCEN_14757.getVectorLayerByName("Surfaces_uniques_par_classe_de_profondeur")
            DicoJ=fonctionsCEN_14757.Echantillonne(f,PEch,ListNBFJour,BATHY)
            #QMessageBox.information(None,"information :","test dicoJ: "+ str(DicoJ))
            
            LayerPlan= QgsVectorLayer("Point", "Plan_d_echantillonnage", "memory")
            QgsProject.instance().addMapLayer(LayerPlan)
            prLayerPlan = LayerPlan.dataProvider()
            prLayerPlan.addAttributes([ QgsField("Num_Ech", QVariant.Int),
                                        QgsField("Jour", QVariant.Int),
                                        QgsField("NumEchJour", QVariant.Int),
                                      QgsField("NumStrates", QVariant.Int),
                                      QgsField("NomStrates",QVariant.String ),
                                      QgsField("XL93", QVariant.Double),
                                     QgsField("YL93", QVariant.Double)])  
            counterProgess=0
            LayerPlan.startEditing()
            for key in list(DicoJ.keys()):
                counterProgess=counterProgess+1
                """
                # creation point avec  geomPlan=QgsGeometry.fromPointXY(QgsPointXY(X,Y)))
                #https://www.programcreek.com/python/example/83790/PyQt5.QtCore.QPoint
                #https://qgis.org/pyqgis/master/core/QgsPointXY.html?highlight=qgspointxy
                X=float('{:10.2f}'.format(float(DicoJ[key][4])))
                Y=float('{:10.2f}'.format(float(DicoJ[key][5])))
                ptf=QgsPointXY(X,Y)
                geomPlan=QgsGeometry.fromPointXY(ptf)
                """
                #Remarque marche aussi avec from wkt
                #QMessageBox.information(None,"DEBUG", str('POINT ('+X+' '+Y+')'))
                X='{:10.2f}'.format(float(DicoJ[key][4]))
                Y='{:10.2f}'.format(float(DicoJ[key][5]))
                geomPlan=QgsGeometry.fromWkt('POINT ('+X+' '+Y+')')
                newfeat=QgsFeature()
                newfeat.setGeometry(geomPlan)
                Values= []
                Values.append(key)
                Values.append(DicoJ[key][0])
                Values.append(DicoJ[key][1])
                Values.append(DicoJ[key][2])
                Values.append(DicoJ[key][3])
                Values.append(DicoJ[key][4])
                Values.append(DicoJ[key][5])
                #QMessageBox.information(None,"DEBUG", str(Values))
                newfeat.setAttributes(Values)
                #bascule en mode �dition- comme ic�ne crayon  :
                # ce qui suit ajoute les g�om et valeurs des enregistrements,
                prLayerPlan.addFeatures([newfeat])
                # m�me effet que: LayerF.addFeature(newfeat,True)
                #Quitte le mode �dition et enregistre les modifs:
                zPercent = int(100 * counterProgess / int(NBF))
                self.progressBar.setValue(zPercent)
                
            LayerPlan.commitChanges()
            self.iface.mapCanvas().refresh()
            
