
# -*- coding: iso-8859-1 -*-
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtGui import *

from qgis.gui import QgsMessageBar,QgsMapCanvas
from qgis.core import *
from PyQt5 import QtCore, QtGui
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from qgis.PyQt.QtWidgets import QDialog, QDialogButtonBox,QAction
# Initialize Qt resources from file resources.py

# Import libs 
import timeit, math, sys, os.path; sys.path.append(os.path.dirname(os.path.abspath(__file__)))

#import de la classe bo�te de dialogue "A propos ..."
from about import Ui_Dialog

class Dialog(QDialog, Ui_Dialog):
	def __init__(self):
		QDialog.__init__(self)
		self.setupUi(self)
		
