# -*- coding: iso-8859-1 -*-
import datetime
from PyQt4 import QtCore, QtGui

#n�cessaire pour les connections signals / slots
from PyQt4.QtCore import *
from PyQt4.QtGui import *
import os.path

# import de QGIS
from qgis import *
from qgis.core import *
from qgis.gui import *
from qgis.gui import QgsMapCanvas
from qgis.utils import iface
import shapely
from shapely.wkb import loads
from qgis.utils import iface

import processing

import os.path
import os
import fonctionsCEN_14757
import doAbout



class Ui_Dialog(object):
    def __init__(self, iface):
        self.iface = iface
    
    def setupUi(self, Dialog):
        largeur=460
        hauteur=620
        self.iface = iface
        Dialog.setObjectName("Dialog")
        Dialog.resize(QtCore.QSize(QtCore.QRect(0,0, largeur,hauteur).size()).expandedTo(Dialog.minimumSizeHint()))
        Dialog.setWindowTitle("G�n�rateur d'abaque modifi�e pour l'�chantillonnage de ce lac ")
        
	# QLabel de couche Polygon
        self.label = QtGui.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(15,10,280,23))
        self.label.setObjectName("label")
        self.label.setText("<u>S�lectionner la couche des isobathes :</u>")

        ListeCouchesPolygon=[""]
        NbCouches=self.iface.mapCanvas().layerCount()
        if NbCouches==0: QMessageBox.information(None,"information:","Pas de couches ! ")
        else:
            for i in range(0,NbCouches):
                couche=self.iface.mapCanvas().layer(i)
                # 2 pour Polygon
                if couche.geometryType()== 2:
                    if couche.isValid():
                       ListeCouchesPolygon.append(couche.name())
                    else:
                       QMessageBox.information(None,"information:","pas de couches d'objets polygones")
                       return None
                    
        self.ComboBoxPolygons = QtGui.QComboBox(Dialog)
        self.ComboBoxPolygons.setMinimumSize(QtCore.QSize(300, 25))
        self.ComboBoxPolygons.setMaximumSize(QtCore.QSize(300, 25))
        self.ComboBoxPolygons.setGeometry(QtCore.QRect(10, 40, 300,25))
        self.ComboBoxPolygons.setObjectName("ComboBoxPolygons")
        for i in range(len(ListeCouchesPolygon)):  self.ComboBoxPolygons.addItem(ListeCouchesPolygon[i])

        #Exemple de QPushButton
        self.DoButton = QtGui.QPushButton(Dialog)
        self.DoButton.setMinimumSize(QtCore.QSize(200, 20))
        self.DoButton.setMaximumSize(QtCore.QSize(200, 20))        
        self.DoButton.setGeometry(QtCore.QRect(60,80, 200, 20))
        self.DoButton.setObjectName("DoButton")
        self.DoButton.setText(" Lancer la lecture de l'abaque !")


        # QLabel entrer le nb de filets par jour
        self.labelnbfilets = QtGui.QLabel(Dialog)
        self.labelnbfilets.setGeometry(QtCore.QRect(15,125,300,20))
        self.labelnbfilets.setObjectName("labelnbfilets")
        self.labelnbfilets.setText("<u> La norme pr�conise un nombre de filets = </u>")

        #QLabel pose NBF
        self.labelNBF = QtGui.QLabel(Dialog)
        self.labelNBF.setGeometry(QtCore.QRect(225,125,90,20))
        self.labelNBF.setObjectName("labelNBF")
        self.labelNBF.setText("<u>non encore calcul� </u>")
        
        # QLabel entrer le nb de filets par jour
        self.labelPmax = QtGui.QLabel(Dialog)
        self.labelPmax.setGeometry(QtCore.QRect(15,155,300,20))
        self.labelPmax.setObjectName("labelPmax")
        self.labelPmax.setText("<u> Renseigner le nombre de filets par strates de profondeur:</u>")
        
        #QLabel pose J1
        
       
        self.labeJ1 = QtGui.QLabel(Dialog)
        self.labeJ1.setGeometry(QtCore.QRect(15,185,160,18))
        self.labeJ1.setObjectName("labelJ1")
        self.labeJ1.setText("<u>Strate 0-3m</u> ,   nb pr�conis� : ")
        
        self.TextEditJ1 = QtGui.QLineEdit(Dialog)
        self.TextEditJ1.setMinimumSize(QtCore.QSize(50, 20))
        self.TextEditJ1.setMaximumSize(QtCore.QSize(50, 20))
        self.TextEditJ1.setGeometry(QtCore.QRect(200, 185, 50,20))
        self.TextEditJ1.setObjectName("TextEditJ1")

        self.labeJ1suite = QtGui.QLabel(Dialog)
        self.labeJ1suite .setGeometry(QtCore.QRect(240,185,110,18))
        self.labeJ1suite .setObjectName("labelJ1suite ")
        self.labeJ1suite .setText(" ,votre nombre : ")
        
        self.TextEditJ1suite  = QtGui.QLineEdit(Dialog)
        self.TextEditJ1suite .setMinimumSize(QtCore.QSize(50, 20))
        self.TextEditJ1suite .setMaximumSize(QtCore.QSize(50, 20))
        self.TextEditJ1suite .setGeometry(QtCore.QRect(320, 185, 50,20))
        self.TextEditJ1suite .setObjectName("TextEditJ1suite ")
       
        #QLabel pose J2
        self.labeJ2 = QtGui.QLabel(Dialog)
        self.labeJ2.setGeometry(QtCore.QRect(15,215,90,18))
        self.labeJ2.setObjectName("labelJ2")
        self.labeJ2.setText("<u>Jour 2: </u>")
        
        self.TextEditJ2 = QtGui.QLineEdit(Dialog)
        self.TextEditJ2.setMinimumSize(QtCore.QSize(50, 20))
        self.TextEditJ2.setMaximumSize(QtCore.QSize(50, 20))
        self.TextEditJ2.setGeometry(QtCore.QRect(110,215,50,20))
        self.TextEditJ2.setObjectName("TextEditJ2")

        #QLabel pose J3
        self.labeJ3 = QtGui.QLabel(Dialog)
        self.labeJ3.setGeometry(QtCore.QRect(15,245,90,18))
        self.labeJ3.setObjectName("labelJ3")
        self.labeJ3.setText("<u>Jour 3: </u>")
        
        self.TextEditJ3 = QtGui.QLineEdit(Dialog)
        self.TextEditJ3.setMinimumSize(QtCore.QSize(50, 20))
        self.TextEditJ3.setMaximumSize(QtCore.QSize(50, 20))
        self.TextEditJ3.setGeometry(QtCore.QRect(110,245, 50,20))
        self.TextEditJ3.setObjectName("TextEditJ3")

        #QLabel pose J4
        self.labeJ4 = QtGui.QLabel(Dialog)
        self.labeJ4.setGeometry(QtCore.QRect(15,275,90,18))
        self.labeJ4.setObjectName("labelJ4")
        self.labeJ4.setText("<u>Jour 4: </u>")
        
        self.TextEditJ4 = QtGui.QLineEdit(Dialog)
        self.TextEditJ4.setMinimumSize(QtCore.QSize(50, 20))
        self.TextEditJ4.setMaximumSize(QtCore.QSize(50, 20))
        self.TextEditJ4.setGeometry(QtCore.QRect(110,275,50,20))
        self.TextEditJ4.setObjectName("TextEditJ4")

        #QLabel pose J5
        self.labeJ5 = QtGui.QLabel(Dialog)
        self.labeJ5.setGeometry(QtCore.QRect(15,305,90,18))
        self.labeJ5.setObjectName("labelJ5")
        self.labeJ5.setText("<u>Jour 5: </u>")
        
        self.TextEditJ5 = QtGui.QLineEdit(Dialog)
        self.TextEditJ5.setMinimumSize(QtCore.QSize(50, 20))
        self.TextEditJ5.setMaximumSize(QtCore.QSize(50, 20))
        self.TextEditJ5.setGeometry(QtCore.QRect(110,305,50,20))
        self.TextEditJ5.setObjectName("TextEditJ5")
        
        self.ENTER = QtGui.QPushButton(Dialog)
        self.ENTER.setMinimumSize(QtCore.QSize(200, 20))
        self.ENTER.setMaximumSize(QtCore.QSize(200, 20))        
        self.ENTER.setGeometry(QtCore.QRect(60,335, 200, 20))
        self.ENTER.setObjectName("ENTER")
        self.ENTER.setText("Valider et lancer les calculs")
        
        
        #Exemple de ProgressBar
        self.progressBar = QtGui.QProgressBar(Dialog)
        self.progressBar.setProperty("value", 0)
        self.progressBar.setMinimumSize(QtCore.QSize(260, 15))
        self.progressBar.setMaximumSize(QtCore.QSize(260, 15))
        self.progressBar.setGeometry(QtCore.QRect(30,455,260,15))
        self.progressBar.setAlignment(QtCore.Qt.AlignCenter)
        self.progressBar.setTextVisible(True)
        self.progressBar.setObjectName("progressBar")
        self.progressBar.setStyleSheet(
            """QProgressBar {border: 2px solid grey; border-radius: 5px; text-align: center;}"""
            """QProgressBar::chunk {background-color: #6C96C6; width: 20px;}"""
            )
        #Pose a minima une valeur de la barre de progression / slide contr�le
        self.progressBar.setValue(0)

        # Panneau Pub !
        self.label_2 = QtGui.QLabel(Dialog)
        self.labelImage = QtGui.QLabel(Dialog)
        self.labelImage.setMinimumSize(QtCore.QSize(300,100))
        self.labelImage.setMaximumSize(QtCore.QSize(300,100))        
        self.labelImage.setGeometry(QtCore.QRect(30, 480, 300,100))
        myPath = os.path.dirname(__file__)+"/data/onema_logo_quad.jpg";
        myDefPath = myPath.replace("\\","/");
        carIcon = QtGui.QImage(myDefPath)
        self.labelImage.setPixmap(QtGui.QPixmap.fromImage(carIcon))
        
        #Exemple de QPushButton
        self.CloseButton = QtGui.QPushButton(Dialog)
        self.CloseButton.setMinimumSize(QtCore.QSize(100, 20))
        self.CloseButton.setMaximumSize(QtCore.QSize(100, 20))        
        self.CloseButton.setGeometry(QtCore.QRect(185, 590,100, 20))
        self.CloseButton.setObjectName("CloseButton")
        self.CloseButton.setText(" Quitter !")
        
        #Exemple de QPushButton
        self.aboutButton = QtGui.QPushButton(Dialog)
        self.aboutButton.setMinimumSize(QtCore.QSize(70, 20))
        self.aboutButton.setMaximumSize(QtCore.QSize(70, 20))        
        self.aboutButton.setGeometry(QtCore.QRect(30, 590, 70, 23))
        self.aboutButton.setObjectName("aboutButton")
        self.aboutButton.setText(" A propos...")

        # Connexion des slots et des actions li�es
        QtCore.QObject.connect(self.CloseButton,QtCore.SIGNAL("clicked()"),Dialog.reject)
        QtCore.QObject.connect(self.ComboBoxPolygons,QtCore.SIGNAL("currentIndexChanged(QString)"),self.onComboL)
        
        QtCore.QObject.connect(self.ENTER, SIGNAL("clicked()"), self.onComboT)
        QtCore.QObject.connect(self.aboutButton, SIGNAL("clicked()"), self.doAbout)
        QtCore.QObject.connect(self.DoButton, SIGNAL("clicked()"), self.Run)
        QtCore.QMetaObject.connectSlotsByName(Dialog)
        
        #
        
    def onComboL(self):
        SelectionP = self.ComboBoxPolygons.currentText()
        #QMessageBox.information(None,"information:","couche selectionnee: "+ (SelectionP))
        CoucheP=fonctionsCEN_14757.getVectorLayerByName(SelectionP)
        counterP=0
        for featP in CoucheP.getFeatures():
            counterP+=1
        #QMessageBox.information(None,"information:","La couche_"+ str(CoucheP.name())+" contient: " + str(counterP)+" objets isobathes !")
        if counterP==0:
            QMessageBox.information(None,"information:","La couche_"+ str(CoucheP.name())+" ne contient pas d'objets !")
            
    
    def doAbout(self):
        d = doAbout.Dialog()
        d.exec_()
           
    def Run(self):
        self.iface = iface
        SelectionP = self.ComboBoxPolygons.currentText()
        CoucheP=fonctionsCEN_14757.getVectorLayerByName(SelectionP)
        
        myPath = os.path.dirname(__file__)+"/data/AbaqueRepFilets.csv";
        uri = myPath.replace("\\","/")
        #QMessageBox.information(None,"information:","test: "+ str(uri))
        #uri="C:/Program Files/QGIS Dufour/apps/qgis/python/plugins/CEN_14757/data/AbaqueRepFilets.csv"
        erreur, dictPlanEch = fonctionsCEN_14757.ouvre_csv_abaque(uri)
        if erreur=="OK":
            StratPmax=fonctionsCEN_14757.maxProf(CoucheP)
        #QMessageBox.information(None,"information:","test: "+ str(dictPlanEch))
        """
        processing.runalg("qgis:linestopolygons",SelectionP,"Prof_Surf_Lac1.shp")
        processing.runalg("qgis:exportaddgeometrycolumns","Prof_Surf_Lac1.shp",0,"Prof_Surf_Lac2.shp")
        zlayerPS=iface.addVectorLayer("Prof_Surf_Lac2.shp","Prof_Surf_Lac_Etape1",'ogr')
        QgsMapLayerRegistry.instance().addMapLayer(zlayerPS)
        self.iface.mapCanvas().refresh()
        """
        processing.runalg("qgis:dissolve",SelectionP,False,"profondeur","Prof_Surf_polygonized.shp")
        processing.runalg("qgis:exportaddgeometrycolumns","Prof_Surf_polygonized.shp",0,"Prof_Surf_Lac_Polygonized.shp")
        zlayerS2=iface.addVectorLayer("Prof_Surf_Lac_Polygonized.shp","ISOBATHES_Lac_Etape1",'ogr')
        self.iface.mapCanvas().refresh()
        QgsMapLayerRegistry.instance().addMapLayer(zlayerS2)
        surftot=0
        # Variante de calcul avec fonction maxsurf recherchant la surface maximale
        #surftot2=0
        #surftot2=fonctionsCEN_14757.maxSurf(zlayerS2)
        for fet in zlayerS2.getFeatures():
            if fet[0]==0: surftot+=fet[1]
        # surftot passage de m2 � ha !
        surftot=surftot/10000
        #surftot2=surftot2/10000
        #QMessageBox.information(None,"information:","test surftot: "+ str(surftot))
        #QMessageBox.information(None,"information:","test surftot2: "+ str(surftot2))
        PEch={}
        PEch,NBF=fonctionsCEN_14757.PlanEch(StratPmax,surftot,dictPlanEch)
        vald=valc=0
        toto=""
        for i in PEch.keys():
            toto= toto + "- pour la strate "+ str(PEch[i][1])+ " : " +str(PEch[i][0])+ " filets" + "\n"
        QMessageBox.information(None,"information:","La surface en eau du lac est de {0:.2f}".format(surftot)+ " hectares." +"\n"+
                                 "La profondeur maximale d�passe les " +str(StratPmax)+" m�tres."+ "\n"+"\n"+
                                "D'apr�s la norme CEN_14757, il faut d�ployer "  + str(NBF)+ " filets."+ "\n"+ "\n"+
                                "et le plan d'�chantillonnage par strate doit �tre : " + "\n" +"\n"+  str(toto))
        self.labelNBF.setText(str(NBF))
        self.TextEditJ1.setText(str(0))
        self.TextEditJ2.setText(str(0))
        self.TextEditJ3.setText(str(0))
        self.TextEditJ4.setText(str(0))
        self.TextEditJ5.setText(str(0))
        
        """
        # pour preremplissage automatique des nb filets jours
        vald=(int(NBF)/5)
        valc=(int(NBF)/5)+(int(NBF)%5)
        self.TextEditJ1.setText(str(valc))
        self.TextEditJ2.setText(str(vald))
        self.TextEditJ3.setText(str(vald))
        self.TextEditJ4.setText(str(vald))
        self.TextEditJ5.setText(str(vald))
        """
        
    def onComboT(self):
        self.iface = iface
        CoucheLac=fonctionsCEN_14757.getVectorLayerByName("ISOBATHES_Lac_Etape1")
        myPath = os.path.dirname(__file__)+"/data/AbaqueRepFilets.csv";
        uri = myPath.replace("\\","/")
        #uri="C:/Program Files/QGIS Dufour/apps/qgis/python/plugins/CEN_14757/data/AbaqueRepFilets.csv"
        erreur, dictPlanEch = fonctionsCEN_14757.ouvre_csv_abaque(uri)
        if erreur=="OK":
            Pmax=fonctionsCEN_14757.maxProf(CoucheLac)
        #QMessageBox.information(None,"information:","test: "+ str(dictPlanEch))
        
        surftot=0
        for fet in CoucheLac.getFeatures():
            if fet[0]==0: surftot+=fet[1]
        # surftot passage de m2 � ha !
        surftot=surftot/10000
        #
        PEch={}
        DicoJ={}
        PEch,NBF=fonctionsCEN_14757.PlanEch(Pmax,surftot,dictPlanEch)
        ListNBFJour=[]
        S=a=b=c=d=e=f=0
        f=int(NBF)
        self.nbFJ1=self.TextEditJ1.text()
        a=int(self.nbFJ1)
        self.nbFJ2=self.TextEditJ2.text()
        b=int(self.nbFJ2)
        self.nbFJ3=self.TextEditJ3.text()
        c=int(self.nbFJ3)
        self.nbFJ4=self.TextEditJ4.text()
        d=int(self.nbFJ4)
        self.nbFJ5=self.TextEditJ5.text()
        e=int(self.nbFJ5)
        S=(a+b+c+d+e)
        ListNBFJour=[a,b,c,d,e]
        if S!=f:
            QMessageBox.information(None,"information:","Vous proposez un total de "+ str(S)+" filets, corrigez pour atteindre "+ str(f))
        else:
            
            CoucheSURF=fonctionsCEN_14757.getVectorLayerByName("ISOBATHES_Lac_Etape1")
            CounterEssais=0
            DicoJ=fonctionsCEN_14757.Echantillonne(f,PEch,ListNBFJour,CoucheSURF)
            #QMessageBox.information(None,"information:","test: "+ str(DicoJ))
            LayerPlan= QgsVectorLayer("Point", "Plan Echantillonnage global", "memory")
            QgsMapLayerRegistry.instance().addMapLayer(LayerPlan)
            prLayerPlan = LayerPlan.dataProvider()
            prLayerPlan.addAttributes([ QgsField("Num_Ech", QVariant.Int),
                                        QgsField("Jour", QVariant.Int),
                                        QgsField("NumEchJour", QVariant.Int),
                                      QgsField("NumStrates", QVariant.Int),
                                      QgsField("NomStrates",QVariant.String ),
                                      QgsField("XL93", QVariant.Double),
                                     QgsField("YL93", QVariant.Double)])  
            counterProgess=0
            LayerPlan.startEditing()
            for key in DicoJ.keys():
                counterProgess=counterProgess+1
                geomPlan=QgsGeometry.fromPoint(QgsPoint(float(DicoJ[key][4]),float(DicoJ[key][5])))
                #geomPlan=QgsGeometry.fromWkt(DicoJ[key][6])
                #geomPlan=(DicoJ[key][6])
                newfeat=QgsFeature()
                newfeat.setGeometry(geomPlan)
                Values= []
                Values.append(key)
                Values.append(DicoJ[key][0])
                Values.append(DicoJ[key][1])
                Values.append(DicoJ[key][2])
                Values.append(DicoJ[key][3])
                Values.append(DicoJ[key][4])
                Values.append(DicoJ[key][5])
                #QMessageBox.information(None,"DEBUG", str(Values))
                newfeat.setAttributes(Values)
                #bascule en mode �dition- comme ic�ne crayon  :
                # ce qui suit ajoute les g�om et valeurs des enregistrements,
                prLayerPlan.addFeatures([newfeat])
                # m�me effet que: LayerF.addFeature(newfeat,True)
                #Quitte le mode �dition et enregistre les modifs:
                zPercent = int(100 * counterProgess / int(NBF))
                self.progressBar.setValue(zPercent)
                
            LayerPlan.commitChanges()
            self.iface.mapCanvas().refresh()
            
